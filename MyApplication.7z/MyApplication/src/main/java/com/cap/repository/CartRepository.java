package com.cap.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cap.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Long> {
	
	
//	public Cart savedata(int id,String name, String brand, String madein, int price);
	 void delete(Long id);

}
