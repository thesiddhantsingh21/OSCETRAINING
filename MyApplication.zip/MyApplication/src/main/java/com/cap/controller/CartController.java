package com.cap.controller;

import javax.servlet.http.HttpServletRequest; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cap.model.Cart;
import com.cap.services.CartService;
import com.cap.services.ProductService;
import com.cap.services.SellerService;
import com.cap.services.UserService;

@Controller
public class CartController {
	
	@Autowired
	 CartService cartService;
	
	@Autowired
	ProductService productService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	SellerService sellerService;
	
	@RequestMapping("/savetocart")
	public String additems(@ModelAttribute Cart cart)
	{
		cartService.saveitem(cart);
		
		return "welcomepage";
	}
	
	@RequestMapping("/cartitems")
	public String additems(@ModelAttribute Cart cart,@RequestParam Long id, HttpServletRequest request)
	{
		request.setAttribute("product",productService.get(id));
		request.setAttribute("mode","MODE_PREVIEW");
		return "itempreview";
	}
	
	@RequestMapping("/buyitems")
	public String clearitems()
	{
		
		return "null";
	}
	
	@RequestMapping("/deleteitemfromcart")
	public String deleteitem(@RequestParam Long id, HttpServletRequest request)
	{
		cartService.deleteitem(id);
		request.setAttribute("items", cartService.listAll());
		request.setAttribute("mode", "ALL_ITEMS");
		return "cart";
	}
}
