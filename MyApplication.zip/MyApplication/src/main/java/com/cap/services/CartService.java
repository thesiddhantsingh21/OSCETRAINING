package com.cap.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cap.model.Cart;
import com.cap.repository.CartRepository;

@Service
@Transactional
public class CartService {

	private CartRepository cartRepository;

	public CartService(CartRepository cartRepository) {
		this.cartRepository = cartRepository;
	}

	
	  public Cart saveitem(Cart cart) {
		  return cartRepository.save(cart);
	  
	  }
	 

	public List<Cart> listAll() {
		return cartRepository.findAll();
	}

	public void deleteitem(Long id) {
		cartRepository.delete(id);;
	}

}
