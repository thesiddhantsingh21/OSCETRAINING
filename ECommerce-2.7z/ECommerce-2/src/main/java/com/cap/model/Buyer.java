package com.cap.model;

import javax.persistence.Entity;

import javax.persistence.Table;


@Entity
@Table(name="buyers")
public class Buyer {
	
	private String Name;
	private int age;
	private String username;
	private int number;
	private String address;
	private String password;
	
	
	public Buyer(String name, int age, String username, int number, String address, String password) {
		super();
		Name = name;
		this.age = age;
		this.username = username;
		this.number = number;
		this.address = address;
		this.password = password;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Buyer [Name=" + Name + ", age=" + age + ", username=" + username + ", number=" + number + ", address="
				+ address + ", password=" + password + "]";
	}
	
	

}
