package com.cap.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.model.Buyer;
import com.cap.repository.BuyerRepository;

@Service
@Transactional
public class BuyerService {
	
	@Autowired
	private final BuyerRepository bu;
	
	public BuyerService(BuyerRepository bu)
	{
		this.bu=bu; 
	}
	
	public void savebuyer(Buyer buyer) {
		
		bu.save(buyer);
	}
}
