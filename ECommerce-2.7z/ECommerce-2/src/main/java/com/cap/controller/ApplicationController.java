package com.cap.controller;

public class ApplicationController {

}
