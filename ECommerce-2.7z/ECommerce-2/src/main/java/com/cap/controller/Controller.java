package com.cap.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cap.model.Buyer;
import com.cap.service.BuyerService;

public class Controller {
	
	@Autowired
	BuyerService bs;
	
	@GetMapping("/saveuser")
	public String saveBuyer(@RequestParam String name, @RequestParam int age, @RequestParam String username, @RequestParam int number, @RequestParam String address, @RequestParam String password )
	{
		Buyer buyer= new Buyer(name,age,username,number,address,password);
		bs.savebuyer(buyer);
		return "home";
	}
	
	@RequestMapping("/welcome")
	public String welcome()
	{
		return "welcomepage";
	}

}
