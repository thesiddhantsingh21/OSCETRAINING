package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exception.InvalidInputException;
import com.model.Pizza_Menu;
import com.model.Pizza_Order;
import com.repository.Order_Repository;
import com.repository.Pizza_Repository;

@Service
public class Pizza_ServiceImpl implements Pizza_Service {
	@Autowired
	Pizza_Repository pizzaRepo;
	@Autowired
	Order_Repository orderRepo;
	
	public List<Pizza_Menu> getPizzaMenu()
	{
		return pizzaRepo.findAll();
	}
	
	public Pizza_Menu addPizzaMenu(Long pizzaId, String pizzaName, int pizzaPrice)
	{
		Pizza_Menu pizzaMenu=new Pizza_Menu();
		
		pizzaMenu.setPizzaId(pizzaId);
		pizzaMenu.setPizzaName(pizzaName);
		pizzaMenu.setPizzaPrice(pizzaPrice);
		pizzaRepo.save(pizzaMenu);
		return pizzaMenu;
	}
	
	public List<Pizza_Order> getOrderDetails()
	{
		return orderRepo.findAll();
	}
	
	/*public Pizza_Menu updateMenu(Long pizzaId, String pizzaName, int pizzaPrice) throws InvalidInputException
	{
		
		Optional<Pizza_Menu>	pizzaMenu =pizzaRepo.findById(pizzaId);
		if(pizzaMenu==null)
		{
			throw new InvalidInputException("Sorry this ID Does Not Exists");
		}
		Pizza_Menu pizza_Menu=new Pizza_Menu();
		pizza_Menu.setPizzaId(pizzaId);
		pizza_Menu.setPizzaName(pizzaName);
		pizza_Menu.setPizzaPrice(pizzaPrice);
		return pizza_Menu;
	}*/
	
	
	public Pizza_Order addPizzaMenu(Long orderId, int pizzaId, String customerName, String customerAddress,
			String customerPhoneNo)
	{
		Pizza_Order pizzaOrder=new Pizza_Order();
		
		pizzaOrder.setOrderId(orderId);
		pizzaOrder.setPizzaId(pizzaId);
		pizzaOrder.setCustomerName(customerName);
		pizzaOrder.setCustomerAddress(customerAddress);
		pizzaOrder.setCustomerPhoneNo(customerPhoneNo);
		orderRepo.save(pizzaOrder);
		return pizzaOrder;
		
	}
	
	public Optional<Pizza_Order> viewOrderDetails(Long orderId) throws InvalidInputException
	{
		 Optional<Pizza_Order> pizzaOrder=orderRepo.findById(orderId);
		 if(pizzaOrder==null)
		 {
			 throw new InvalidInputException("Sorry this ID Does Not Exists");
		 }
		 
		 return orderRepo.findById(orderId);
	}
	

}
