package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Pizza_Order;

@Repository
public interface Order_Repository extends JpaRepository<Pizza_Order, Long> {

}
